// The carton sticker: read by the hand who packed it and the driver who receives it,
// often at the same moment — so its labels carry both languages at once, and the
// wordmark is the asset file rather than characters arranged to look like it.
const fs=require('fs');const {JSDOM,VirtualConsole}=require('/home/claude/work/node_modules/jsdom');
let f=0,n=0;const ok=(c,m)=>{n++;console.log((c?'  ✓ ':'  ✗ FAIL ')+m);if(!c)f++;};
const load=lang=>{const w=new JSDOM(fs.readFileSync('ShopyLink_Action_01_ReceiveParcel.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.test',virtualConsole:new VirtualConsole()}).window;
  if(lang==='ar'&&w.setLang)w.setLang('ar'); w.go('done'); return w;};

console.log('§141 the brand is the asset (A1)');
const w=load('en');
const img=w.document.querySelector('.awb img');
ok(!!img,'the sticker carries the wordmark as an image');
ok(img.src.split(',')[1]===fs.readFileSync('/mnt/project/wordmarkmonowhite.png').toString('base64'),
   '…byte for byte /mnt/project/wordmarkmonowhite.png, not drawn from shapes');
ok(!/>shopy</.test(w.document.querySelector('.awb').innerHTML),'no typed "shopy" remains');

console.log('§142 both readers, one sticker');
const core=['المرسِل / المتجر','المرسَل إليه','البنود الجمركية','القيمة المصرَّحة','الوزن المحتسَب','التاريخ','الوزن الإجمالي'];
['en','ar'].forEach(lang=>{
  const t=load(lang).document.querySelector('.awb').textContent.replace(/\s+/g,' ');
  const miss=core.filter(x=>!t.includes(x));
  ok(miss.length===0,lang+' mode: '+core.length+' labels carry Arabic beside English'+(miss.length?' — missing '+miss.join(', '):''));
  ok(/SL-/.test(t),'   the shipment id stays Latin (B2)');
  ok(/kg/.test(t),'   …and so do the weights');
});
const ar=load('ar').document.querySelector('.awb').textContent;
ok(/عدد الطرود/.test(ar),'the carton count reads in Arabic for an Arabic operator');

console.log('§143 the sticker still does its job');
ok(/AWB|CMR|B\/L/.test(w.document.querySelector('.awb').textContent),'it names the transport document type');
ok(w.document.querySelector('.awb svg')||/barcode/i.test(w.document.querySelector('.awb').innerHTML),'…and carries something scannable');
console.log('\n'+(f?('FAIL — '+f+' of '+n):('ALL PASS — '+n+' checks')));
process.exit(f?1:0);
