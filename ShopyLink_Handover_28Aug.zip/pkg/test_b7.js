const fs=require('fs');const {JSDOM}=require('jsdom');
const html=fs.readFileSync('ShopyLink_Action_07_Dispatcher.html','utf8');
let errs=[];
const dom=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,
  virtualConsole:new (require('jsdom').VirtualConsole)().on('jsdomError',e=>errs.push(e.message)).on('error',e=>errs.push(e))});
const w=dom.window, d=w.document;
const shell=()=>d.getElementById('shell').innerHTML;
const len=()=>shell().length;
let fail=0;
const ok=(c,m)=>{console.log((c?'  ✓ ':'  ✗ FAIL ')+m); if(!c)fail++;};

console.log('\n[states]');
['s1','s2-pre','s3-pre','done'].forEach(s=>{
  w.resetB7(); w.go(s); ok(len()>400, s+' renders ('+len()+' chars)');
  ok(d.querySelectorAll('.sl-sim-btn.on').length===1, s+' sim highlight');
  ok(/class="foot"/.test(shell()), s+' sticky footer');
});

console.log('\n[paid gate]');
w.resetB7(); w.go('s1');
ok(/Awaiting payment/.test(shell()),'unpaid section rendered separately');
ok(w.readyInZone('Z-MEZ').length===2,'Mezzeh ready = 2 (unpaid Rana excluded)');
ok(w.readyInZone('Z-JAR').length===1,'Jaramana ready = 1 (paid business in, unpaid Hadi out)');
ok(w.readyInZone('Z-MID').length===1,'Midan ready = 1 (unpaid BUSINESS Sham excluded — universal gate)');
ok(w.unpaidList().some(x=>x.id==='DLV-2608-08'),'unpaid business appears in Awaiting payment section');
ok(!w.readyInZone('Z-MEZ').some(x=>x.id==='DLV-2608-05'),'unpaid individual never enters pool');
w.remind('DLV-2608-05');
ok(!!w.st.reminded['DLV-2608-05'],'WhatsApp reminder stamps time');

console.log('\n[assign flow]');
w.pickZone('Z-MEZ');
ok(w.sim==='s2','pickZone → s2');
ok(w.selCount()===2,'all ready selected by default');
ok(w.st.driver==='DRV-01','available zone driver auto-suggested');
w.toggleSel('DLV-2608-02');
ok(w.selCount()===1,'untick excludes a delivery');
w.toggleSel('DLV-2608-02');
w.pickDriver('DRV-04');
ok(w.st.driver!=='DRV-04','offline driver cannot be picked');
w.pickDriver('DRV-03');
ok(w.st.driver==='DRV-03','busy driver still pickable');
w.doAssign();
ok(w.sim==='s3','assign → monitor');
ok(w.st.runs.length===1&&w.st.runs[0].rst==='assigned','run created, status assigned');
ok(w.dst['DLV-2608-01']==='assigned','delivery status → assigned');
ok(w.readyInZone('Z-MEZ').length===0,'assigned deliveries left the pool');

console.log('\n[monitor: decline / reassign / accept]');
const rid=w.st.runs[0].id;
w.simDecline(rid);
ok(w.st.runs.length===0,'decline removes the run');
ok(w.dst['DLV-2608-01']==='ready','declined deliveries back to ready');
w.pickZone('Z-MEZ'); w.doAssign();
const rid2=w.st.runs[0].id;
w.reassign(rid2);
ok(w.sim==='s2'&&w.st.zone==='Z-MEZ','reassign reopens assign with zone preset');
ok(w.selCount()===2,'reassign preselects the same deliveries');
w.doAssign();
const rid3=w.st.runs[0].id;
w.simAccept(rid3);
ok(w.st.runs[0].rst==='accepted'&&!!w.st.runs[0].acceptedAt,'accept → out_for_delivery + timestamp');
ok(w.dst['DLV-2608-01']==='accepted','delivery status → accepted');
w.simAccept(rid3);
ok(w.st.runs.length===1,'double-accept is a no-op');
w.reassign(rid3);
ok(w.st.runs[0].rst==='accepted','accepted run cannot be reassigned');

console.log('\n[summary]');
w.go('done');
ok(/Run out for delivery|الجولة/.test(shell()),'done renders');
ok(/RUN-260818/.test(shell()),'run chip shown');

console.log('\n[prepaid-only]');
w.resetB7(); w.pickZone('Z-JAR');
ok(!/COD badge/.test(shell()),'no COD badges anywhere (prepaid-only)');

console.log('\n[arabic]');
w.setLang('ar'); w.go('s1');
ok(d.documentElement.dir==='rtl','RTL applied');
ok(/لوحة التوزيع/.test(shell()),'AR board strings');
ok(/بانتظار الدفع/.test(shell()),'AR unpaid section');
w.setLang('en');

console.log('\nconsole errors: '+errs.length); errs.slice(0,5).forEach(e=>console.log('   '+e));
console.log('\nRESULT: '+(fail||errs.length?'FAIL ('+fail+')':'ALL PASS')+'\n');
process.exit(fail||errs.length?1:0);
